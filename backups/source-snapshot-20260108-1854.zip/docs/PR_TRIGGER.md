Trigger file to create a visible PR for review.

This file was added by the automation agent to produce a small diff so you can open a PR and run CI/E2E.

Remove this file after review if you prefer.
