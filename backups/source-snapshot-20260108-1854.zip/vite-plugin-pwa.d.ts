declare module 'vite-plugin-pwa';
